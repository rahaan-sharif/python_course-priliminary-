import csv
# For the average
from statistics import mean 


def calculate_averages(input_file_name, output_file_name):
    f_in=open(input_file_name)
    my_data=csv.reader(f_in,delimiter=",")
    nemes=[]
    bod1=[]
    bod2=[]
    for row in my_data:
            name=row[0]
            grades=row[1:]
            my_list=[]
            for grade in grades:
                
                my_list+=[float(grade)]
        

            miangin=mean(my_list)
            bod1=[name,miangin]
            bod2=bod2+[bod1]
    f_in.close()
    ##
    f_out=open(output_file_name,"w",newline="")
    writer=csv.writer(f_out)
    writer.writerows(bod2)
    f_out.close()
    



def calculate_sorted_averages(input_file_name, output_file_name):# دومین عبارت
    

    f_in=open(input_file_name)
    my_data=csv.reader(f_in,delimiter=",")
    names=[]
    nomarat=[]
    bod1=[]
    bod2=[]
    khorooji=dict()
    for row in my_data:
            name=row[0]
            names=names+[name]
            grades=row[1:]
            my_list=[]
            for grade in grades:
                my_list+=[float(grade)]
        

            miangin=mean(my_list)
            khorooji[name]=miangin
            nomarat+=[miangin]
    ##############################################################
    nomarat.sort()
    new_name=[]
    names.sort()
    for miane in nomarat:
        for n in names:
            if khorooji[n]==miane:
                new_name+=[n]
                names.remove(n)
                break
    names=new_name

    ##############################################################
    for esm in names:
        bod1=[esm,khorooji[esm]]
        bod2+=[bod1]
        
    f_in.close()
    ##
    f_out=open(output_file_name,"w",newline="")
    writer=csv.writer(f_out)
    writer.writerows(bod2)
    f_out.close()
    


def calculate_three_best(input_file_name, output_file_name):
        

    f_in=open(input_file_name)
    my_data=csv.reader(f_in,delimiter=",")
    names=[]
    nomarat=[]
    bod1=[]
    bod2=[]
    khorooji=dict()
    for row in my_data:
            name=row[0]
            names=names+[name]
            grades=row[1:]
            my_list=[]
            for grade in grades:
                my_list+=[float(grade)]
        

            miangin=mean(my_list)
            khorooji[name]=miangin
            nomarat+=[miangin]
    ###############################
    ####################################################
    nomarat.sort()
    new_name=[]
    names.sort()
    for miane in nomarat:
        for n in names:
            if khorooji[n]==miane:
                new_name+=[n]
                names.remove(n)
                break
    names=new_name
    #####################################################
    ###############################

    for esm in names:
       # print(khorooji[esm])
        bod1=[esm,khorooji[esm]]
        bod2+=[bod1]
    
    tedad=len(bod2)-1
    bod2=[bod2[tedad]]+[bod2[tedad-1]]+[bod2[tedad-2]]
    #print("bod2 is",bod2)
        
    f_in.close()
    ##
    f_out=open(output_file_name,"w",newline="")
    writer=csv.writer(f_out)
    writer.writerows(bod2)
    f_out.close()
    


def calculate_three_worst(input_file_name, output_file_name):
    f_in=open(input_file_name)
    my_data=csv.reader(f_in,delimiter=",")
    names=[]
    nomarat=[]
    bod1=[]
    bod2=[]
    khorooji=dict()
    for row in my_data:
            name=row[0]
            names=names+[name]
            grades=row[1:]
            my_list=[]
            for grade in grades:
                my_list+=[float(grade)]
        

            miangin=mean(my_list)
            khorooji[name]=miangin
            nomarat+=[miangin]
    ###############################
    ####################################################
    nomarat.sort()
    new_name=[]
    names.sort()
    for miane in nomarat:
        for n in names:
            if khorooji[n]==miane:
                new_name+=[n]
                names.remove(n)
                break
    names=new_name
    #####################################################
    ###############################

    for esm in names:
        #print(khorooji[esm])
        bod2+=[khorooji[esm]]
        
    


    tedad=len(bod2)-1
    bod2=[[bod2[0]]]+[[bod2[1]]]+[[bod2[2]]]
    #print(bod2)

   # print("bod2 is",bod2)
        
    f_in.close()
    ##
    f_out=open(output_file_name,"w",newline="")
    writer=csv.writer(f_out)
    writer.writerows(bod2)
    f_out.close()
    


def calculate_average_of_averages(input_file_name, output_file_name):
    f_in=open(input_file_name)
    my_data=csv.reader(f_in,delimiter=",")
    names=[]
    bod1=[]
    bod2=[]
    for row in my_data:
            name=row[0]
            grades=row[1:]
            my_list=[]
            for grade in grades:
                my_list+=[float(grade)]
        

            miangin=mean(my_list)
           # bod1=[miangin]
            bod2=bod2+[miangin]
    
    bod2=mean(bod2)
    bod2=[bod2]
    f_in.close()
    ##
    bod2=bod2+[]
    f_out=open(output_file_name,"w",newline="")
    writer=csv.writer(f_out)
    writer.writerow(bod2)
    f_out.close()
    


#input_file_name="c:\\Users\\Rahaan_Sharif\\Desktop\\emrooz.csv"
#output_file_name="c:\\Users\\Rahaan_Sharif\\Desktop\\1.csv"
#####----------------------------------------------------------------
#calculate_averages(input_file_name, output_file_name)
#output_file_name="c:\\Users\\Rahaan_Sharif\\Desktop\\2.csv"
#####-------------------------------------------------------------------
#calculate_sorted_averages(input_file_name, output_file_name)
#output_file_name="c:\\Users\\Rahaan_Sharif\\Desktop\\3.csv"
#####--------------------------------------------------------------
#calculate_three_best(input_file_name, output_file_name)
#output_file_name="c:\\Users\\Rahaan_Sharif\\Desktop\\4.csv"
######--------------------------------------------------------------
#calculate_three_worst(input_file_name, output_file_name)
#output_file_name="c:\\Users\\Rahaan_Sharif\\Desktop\\5.csv"
######------------------------------------------------------------------
#calculate_average_of_averages(input_file_name, output_file_name)
