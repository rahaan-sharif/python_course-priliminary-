
import hashlib
import csv

def hash_password_hack(input_file_name, output_file_name):
    f=open(input_file_name)
    my_data=csv.reader(f,delimiter=",")
    my_data=list(my_data)
    names=[]
    bod1=[]
    bod2=[]
    for item in my_data:
        name=item[0]
        names+=[name]
        number=item[1]
        i=0
        while i<10000:
            if hashlib.sha256(str(i).encode()).hexdigest()==number:
                bod1=[name,i]
                bod2=bod2+[bod1]
                break
            i+=1
    
    
    fout=open(output_file_name,"w",newline="")
    writer=csv.writer(fout)
    writer.writerows(bod2)
    fout.close()


